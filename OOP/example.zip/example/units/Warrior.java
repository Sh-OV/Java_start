package org.example.units;

public abstract class Warrior extends BaseHero {

    public Warrior(float hp, int maxHp, int attack, int damageMin, int damageMax, int defense, int speed, int posX, int posY) {
        super(hp, maxHp, attack, damageMin, damageMax, defense, speed, posX, posY);
    }

}
